"""
Bot Telegram: /sms <phone> <count>
- Chạy: python bot.py
- Yêu cầu: python-telegram-bot >= 20, Python 3.9+
"""

import os
import re
import time
import asyncio
import subprocess
from collections import defaultdict
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# ====== CẤU HÌNH ======
BOT_TOKEN = "7651331068:AAEQUBeNlW6a7WznGSp1gzGdn36l-BLy0Tk"   # ⚠️ Thay token bot Telegram của bạn ở đây
ALLOWED_USERS = {7818408538}         # ⚠️ Thay user_id Telegram của bạn ở đây
SMS_SCRIPT = "dec.py"                # File sms.py nằm cùng thư mục
PYTHON_CMD = "python"                # hoặc "python3" tùy hệ thống
MAX_COUNT = 30                       # Không cho count vượt quá 20
RATE_LIMIT_SECONDS = 30              # Giới hạn 1 lần mỗi 30s mỗi người
# =======================

if not BOT_TOKEN or BOT_TOKEN == "PUT-YOUR-TOKEN-HERE":
    raise SystemExit("❌ Vui lòng đặt BOT_TOKEN trong file bot.py trước khi chạy.")

# Lưu thời điểm dùng lệnh lần cuối của từng user
_last_time = defaultdict(lambda: 0.0)

# Regex kiểm tra số điện thoại
phone_re = re.compile(r'^\+?\d{9,15}$')


async def run_sms_script(phone: str, count: int):
    """Chạy file sms.py qua subprocess"""
    cmd = [PYTHON_CMD, SMS_SCRIPT, phone, str(count)]

    def _run():
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            out = (p.stdout or "") + (p.stderr or "")
            return p.returncode, out
        except Exception as e:
            return 1, f"Lỗi khi chạy script: {e}"

    return await asyncio.to_thread(_run)


async def sms_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id

    # Kiểm tra quyền
    if user_id not in ALLOWED_USERS:
        await context.bot.send_message(chat_id=chat_id, text="🚫 Bạn không có quyền dùng lệnh này.")
        return

    # Kiểm tra tham số
    if len(context.args) != 2:
        await context.bot.send_message(chat_id=chat_id, text="❗ Dùng đúng cú pháp: /sms <số_điện_thoại> <count>")
        return

    phone, count_str = context.args

    if not phone_re.match(phone):
        await context.bot.send_message(chat_id=chat_id, text="⚠️ Số điện thoại không hợp lệ!")
        return

    try:
        count = int(count_str)
        if count <= 0 or count > MAX_COUNT:
            await context.bot.send_message(chat_id=chat_id, text=f"⚠️ Count phải từ 1 đến {MAX_COUNT}")
            return
    except ValueError:
        await context.bot.send_message(chat_id=chat_id, text="⚠️ Count phải là số nguyên!")
        return

    # Giới hạn thời gian giữa các lần
    now = time.time()
    if now - _last_time[user_id] < RATE_LIMIT_SECONDS:
        remain = int(RATE_LIMIT_SECONDS - (now - _last_time[user_id]))
        await context.bot.send_message(chat_id=chat_id, text=f"⏳ Vui lòng chờ {remain}s trước khi chạy lại.")
        return
    _last_time[user_id] = now

    await context.bot.send_message(chat_id=chat_id, text=f"🚀 Đang chạy lệnh: python {SMS_SCRIPT} {phone} {count}")

    # Chạy script sms.py
    code, output = await run_sms_script(phone, count)

    msg = f"✅ Hoàn tất (mã thoát {code}).\n\nKết quả:\n<pre>{output[-3000:]}</pre>"
    await context.bot.send_message(chat_id=chat_id, text=msg, parse_mode="HTML")


def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("sms", sms_command))
    print("🤖 Bot đang chạy... Gõ /sms <sđt> <count> để thử.")
    app.run_polling()

if __name__ == "__main__":
    main()